"""Validate task delivery only, not semantic correctness."""
import argparse, hashlib, json, re, sys
from pathlib import Path

def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return [json.loads(x) for x in p.read_text(encoding='utf-8-sig').splitlines() if x.strip()]
def main():
    p=argparse.ArgumentParser(); p.add_argument('--parts-dir',default='outputs'); p.add_argument('--allow-partial',action='store_true'); a=p.parse_args()
    root=Path(__file__).resolve().parent
    m=json.loads((root/'MANIFEST.json').read_text('utf-8')); qpath=root/'requests_all.jsonl'; q=read(qpath)
    assert sha(qpath.read_bytes())==m['requests_sha256'], 'REQUESTS_HASH_MISMATCH'
    assert len(q)==m['count'] and len({x['id'] for x in q})==len(q), 'REQUEST_ID_MISMATCH'
    out=Path(a.parts_dir); out=out if out.is_absolute() else root/out
    errors=[]; rows=[]; expected_files=set(); absent=[]; present=[]
    for part in m['parts']:
        f=part['output']; expected_files.add(f); path=out/f
        if not path.exists(): absent.append(f); continue
        try:
            r=read(path); e=q[part['start']-1:part['end']]
            if len(r)!=len(e): raise ValueError('wrong part length')
            for x,y in zip(r,e):
                if set(x)!={'id','response_raw'} or x['id']!=y['id'] or not isinstance(x['response_raw'],str) or not x['response_raw'].strip(): raise ValueError('invalid ID/schema/empty response: '+str(y['id']))
                if x['response_raw'].strip().lower() in ('todo','tbd','placeholder','...','待生成','占位符'): raise ValueError('placeholder: '+str(y['id']))
            rows.extend(r); present.append(f)
        except Exception as e: errors.append(f+': '+str(e))
    if out.exists():
        errors.extend('unexpected output: '+x.name for x in out.glob('output_*.jsonl') if x.name not in expected_files)
    ids=[x['id'] for x in rows]; assert len(set(ids))==len(ids)
    merged=root/'validated_responses.jsonl'; merged.write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows),encoding='utf-8')
    report={'stage':m['stage'],'purpose':m['purpose'],'expected':len(q),'validated':len(rows),'missing_parts':absent,'valid_parts':present,'errors':errors,'merged_sha256':sha(merged.read_bytes()),'semantic_validation':'NOT_PERFORMED','status':'COMPLETE' if not errors and not absent else ('PARTIAL' if not errors else 'INVALID')}
    (root/'VALIDATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); print(json.dumps(report,ensure_ascii=False,indent=2))
    return 1 if errors or (absent and not a.allow_partial) else 0
if __name__=='__main__': sys.exit(main())
