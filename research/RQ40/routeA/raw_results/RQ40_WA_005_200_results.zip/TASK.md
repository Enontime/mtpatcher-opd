# 独立 GPT 生成任务：MT-PATCHER 化学扩展（路线 A）
只使用本任务包 requests_all.jsonl 中每条冻结 prompt。逐条独立执行，不改写 prompt，不添加输出格式、长度、类别或主题约束，不使用模板批量填充、程序化替换、占位符或复制其他样本。不得查阅历史会话、其他分包结果、术语标准答案或测试集。重复的 PDS prompt 是独立上下文生成任务，每次独立创作，不交换结果。
每50条保存一个完整分包（最后一包可能不足50条），文件名和范围以 MANIFEST.json 为准。每行仅包含 id、response_raw，原始回答完整保留，不为通过校验而修改。运行 python validate_results.py --parts-dir outputs；未完成则加 --allow-partial。交付原始 outputs、MANIFEST.json、validated_responses.jsonl、VALIDATION.json 和 SHA256，打包为结果 ZIP。执行受限时保存真实完成分包，不虚构剩余答案。校验通过仅说明格式完整。
